var img1;
var img2;
var img3;

function preload() {
  img1 = loadImage('fairy.jpg');
  img2 = loadImage('flowers.jpg');
  img3 = loadImage('giphy.gif')
}


function setup() {
  createCanvas(700, 700);
  textFont("TimesNewRoman")
}

function draw() {
  background(220);
  image(img1, -500, -600);
  image(img2, 20, 300, mouseX * 1, mouseY * 1);
  image(img3, 190, 100);
  textSize(55);
  fill(220, 200, 0)
  text('Autumn Evenings <3', 45, 90);
  
}