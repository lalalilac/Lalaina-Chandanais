var recognizer = new p5.SpeechRec(); // speech recognition object (will prompt for mic access)
recognizer.onResult = showResult; // bind callback function to trigger when speech is recognized
recognizer.interimResults = true;
recognizer.continuous = false;
recognizer.start(); // start listening
var backgroundColor;
var lastLastWord = "";

var speaker = new p5.Speech();
speaker.setPitch(1.5);
speaker.setRate(0.7);


function showResult()
{
  var lastWord = getLastWord();
  
  if (lastWord != lastLastWord) {
    lastLastWord = lastWord;
    
    
    if (lastWord === "green") {
      backgroundColor = color(0, 255, 0);
      speaker.speak(lastWord);
    }
    if (lastWord === "orange") {
      backgroundColor = color(250,150, 0);
      speaker.speak(lastWord);
    }
    
  }
  
  console.log(recognizer.resultString); // log the result
}

function getLastWord() {
  var words = recognizer.resultString.split(" ");
  var lastIndex = words.length - 1;
  if (lastIndex < 0) {
    return "";
  }
  var lastOne = words[lastIndex];
  return lastOne.toLowerCase();
}



function setup() {
  createCanvas(400, 400);
  backgroundColor = color(200, 0, 200);
}

function draw() {
  background(backgroundColor);
  text('say green or orange :D', 49, 100);
  textSize(30)
  
  
}