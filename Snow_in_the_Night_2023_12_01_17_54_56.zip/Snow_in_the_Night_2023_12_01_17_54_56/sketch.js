var flakes = [];

function setup() {
  createCanvas(400, 400);
for(let a = 0; a < width; a++) {
    flakes[a] = random(height);
  }
   stroke(255);
  
}

function draw() {
  background(20);
 
  for(let a = 5; a < flakes.length; a++) {
    flakes[a] += random(3);
    if(flakes[a] > height){
      flakes[a] = 150;
    }
       point(a, flakes[a]);
  }
  cloud(110, 110);
  cloud(180, 110);
  
}  

function cloud(x,y) {
  push();
  translate(x,y);
  stroke(210);
  strokeWeight(70);
  ellipse(45, 10, 20, 10);
  ellipse(-20, 10, 20, 10);
  ellipse(10, -10, 20, 10);
  pop();
}